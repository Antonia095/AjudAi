create function recuperacodigo() returns integer
    language plpgsql
as
$$
DECLARE
		resultado CONTEUDO%RowType;
		cod INTEGER;
	BEGIN
		FOR resultado IN SELECT * FROM Conteudo
		LOOP
			cod:= resultado.Codigo;
		END LOOP;
		RETURN cod;
	END

$$;

alter function recuperacodigo() owner to postgres;

