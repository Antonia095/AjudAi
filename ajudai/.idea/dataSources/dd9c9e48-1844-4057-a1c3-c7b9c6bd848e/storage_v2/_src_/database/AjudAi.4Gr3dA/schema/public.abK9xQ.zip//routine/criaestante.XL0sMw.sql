create function criaestante() returns trigger
    language plpgsql
as
$$
BEGIN
		INSERT INTO ESTANTE(datacriacao,nomeusuario) VALUES(CURRENT_DATE, New.nomeUsuario);
		RETURN New;
	END

$$;

alter function criaestante() owner to postgres;

